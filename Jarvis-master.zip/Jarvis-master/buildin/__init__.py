from buildin.Basic import ChromeCode

KnowApps={"Google Chrome":ChromeCode}

GoodMsg= ["Command executed, sir.",
       "What's the next move, sir?",
       "Task completed, sir.",
       "What's on the agenda, sir?",
       "Mission accomplished, sir.",
       "Ready for the next challenge, sir.",
       "All set, sir.",
       "Awaiting further instructions, sir.",
       "Next step, sir?",
       "Task fulfilled, sir.",
       "What's the plan, sir?",
       "Ready and waiting, sir.",
       "What's the next objective, sir?",
       "Task completed successfully, sir.",
       "What's the next mission, sir?"]