web != None:
                    print(Fore.CYAN + "JARVIS : " + web , flush = True )
                    Speak(web)
                # elif Chat(QL)[1] >= 0.99:
                #     print(Fore.CYAN + "JARVIS : " + Chat(QL)[0] , flush = True )
                #     Speak(Chat(QL)[0])
                else: