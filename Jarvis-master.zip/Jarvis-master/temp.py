from func.SpeakOffline import Speak 
a=5+5
Speak(a)